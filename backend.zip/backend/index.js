const connectToMongo =  require('./db')
const express = require('express');
connectToMongo()
const app = express();
const port = 5000;
var cors = require('cors')
 
app.use(cors())
 


// app.get('/', (req, res) => {
//   res.send('Hello mushu!');
// });

app.use(express.json())
app.use('/api/auth', require('./routes/auth'))
app.use('/api/admissions', require('./routes/admissions'))

app.listen(port, () => {
  console.log(`admission backend listening at http://localhost:${port}`);
})