const express = require('express'); 
const router = express.Router();
const { body, validationResult }= require('express-validator');
const User = require('../models/User');
const JWT_TOKEN = "mushub$oy";
var bcrypt = require('bcryptjs'); // Importing the bcryptjs module to hash passwords.
var jwt = require('jsonwebtoken');
const validate = (validations) => {
    return async (req, res, next) => {
      for (const validation of validations) {
        const result = await validation.run(req); // Running each validation rule.
        if (!result.isEmpty()) {
          return res.status(400).json({ errors: result.array() }); // Returning validation errors if any.
        }
      }
      next(); 
    };
  };

  router.post(
    '/',
    validate([
      body('email').isEmail(), // Validating that email is in correct format.
      body('name').isLength({ min: 3 }), // Validating that name is at least 3 characters long.
      body('password').isLength({ min: 5 }) // Validating that password is at least 5 characters long.
    ]),
    async (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() }); // Returning validation errors if any.
          }
      
          try {
            // Check if user with provided email already exists
            let user = await User.findOne({ email: req.body.email });
            if (user) {
              return res.status(400).json({ errors: [{ msg: 'User already exists' }] }); // Returning error if user exists.
            }
            const salt = await bcrypt.genSalt(10); // Generating salt for hashing the password.
      const securepass = await bcrypt.hash(req.body.password, salt); // Hashing the password using bcrypt.

      // If user doesn't exist, create a new one
      user = new User({
        name: req.body.name,
        password: securepass, // Storing hashed password.
        email: req.body.email,
      });

              // Save the user to the database
      await user.save();

      const data = {
        user: {
          id: user.id
        } 
      }
      const jwtdata = jwt.sign(data, JWT_TOKEN); // Signing a JWT token with user ID.
      console.log(jwtdata);
      return res.json(data);
    }catch (error) {
        console.error('Error creating user:', error.message); // Logging the error message.
        return res.status(500).send('Server Error'); // Returning server error response.
      }})




 router.post     ('/login',validate([
  body('email', 'enter the valid email').isEmail(), // Validating email format.
  body('password', 'enter the password').exists() // Checking that password exists in the request.
]),async(req,res)=>{
let success=false

const errors = validationResult(req); // Checking for validation errors.
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() }); // Returning validation errors if any.
    }

const {email,password}=req.body
try{
  let user=await User.findOne({email})
  if(!user){
    success=false
    return res.status(400).json({ errors: [{ msg: 'Invalid Credentials' }] })

  }
  const passwordcompare=await bcrypt.compare(password,user.password)
  if (!passwordcompare) {
    success=false

    return res.status(400).json({ errors: [{ msg: 'Invalid wrong password Credentials' }] }); // Returning error if passwords don't match.
  }

  const data={
  user:{
    id:user.id
  }
}
const jwtdata=jwt.sign(data,JWT_TOKEN);
success=true
console.log(jwtdata);

  return res.status(200).json({ success:success,token: jwtdata }); 
} catch (error) {
  console.error('Error creating user:', error.message); 
  return res.status(500).send('Server Error'); 
}})
module.exports = router;