

// var fetchuser = require('../middleware/fetchuser'); 

//  const express = require('express');
// const router = express.Router();
// const mongoose = require('mongoose');
// const gridfsStream = require('gridfs-stream');
// const multer = require('multer');
// const crypto = require('crypto');
// const path = require('path');
// const { GridFsStorage } = require('multer-gridfs-storage');
// const Admission = require('../models/Admission');

// // Mongo URI
// const mongoURI = 'mongodb://localhost:27017/admissions';

// // Create mongo connection
// const conn = mongoose.createConnection(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true });

// router.post('/add_admission', fetchuser, async (req, res) => {
//   try {
//   // const { entered } = req.;
//   let enter = await Admission.find(({user:req.user.id}));
//   console.log("entered",enter)
//   if (enter){ res.status(400).json("you have uploaded application already");
//     console.log("you have already applied for one applicationr")}
  
//     const {
//       full_name,
//       date_of_birth,
//       gender,
//       nationality,
//       religion,
//       category,
//       physically,
//       blood,
//       mobile,
//       email,
//       father_name,
//       father_occupation,
//       mother_name,
//       mother_occupation,
//       annual_income,
//       current_add,
//       parent_number,
//       parent_email,
//       image_url,
//       state,
//       ten_school_name,
//       ten_year_passing,
//       ten_maxmarks,
//       ten_obtained_marks,
//       ten_percentage,
//       ten_subject1,
//       ten_subject2,
//       ten_subject3,
//       ten_subject4,
//       ten_subject5,
//       ten_subject6,
//       ten_image_url,
//       tenth_certificate,
//       two_school_name,
//       two_year_passed,
//       two_max_marks,
//       two_obtained_marks,
//       two_percentage,
//       two_image_url,
//       ug_combination,
//       ug_course,
//       pu_course,
//       ten_subject1_name,
//       ten_subject2_name,
//       ten_subject3_name,
//       ten_subject4_name,
//       ten_subject5_name,
//       ten_subject6_name,
//       entered,
//     } = req.body;
//     const newAdmission = new Admission({
//       user: req.user.id,
//       full_name, date_of_birth, gender, nationality, religion, category, physically,entered:true,
//       blood, mobile, email, father_name, father_occupation, mother_name,
//       mother_occupation, annual_income, current_add, parent_number, parent_email,
//       image_url,state,ten_school_name,ten_year_passing,ten_maxmarks,
//       ten_obtained_marks,ten_percentage,ten_subject1,ten_subject2,ten_subject3,
//       ten_subject4,ten_subject5,ten_subject6,ten_image_url,tenth_certificate,two_school_name,
//       two_year_passed,two_max_marks,two_obtained_marks,two_percentage,two_image_url,ug_combination,
//       ug_course,pu_course,ten_subject1_name,ten_subject2_name,ten_subject3_name,ten_subject4_name,ten_subject5_name,ten_subject6_name
//     });

//     await newAdmission.save();
//     res.status(201).json(newAdmission);
//   } catch (error) {
//     console.error('Error in add_admission:', error);
//     res.status(400).json({ error: error.message });
//   }
// }

  

// );

// router.get('/fetchalladdmission',fetchuser  ,async (req,res)=>{ 
//   try{
//       const admin1=await Admission.find(({user:req.user.id}))
//   res.json(admin1)
//   }
//   catch{
//        console.error("Error fetching notes:", error.message);
//       res.status(500).send("Server Error");
  
//   }})

// module.exports = router;





const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const fetchuser = require('../middleware/fetchuser'); 
const Admission = require('../models/Admission');

// Mongo URI
const mongoURI = 'mongodb://localhost:27017/admissions';

// Create mongo connection
const conn = mongoose.createConnection(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true });

router.post('/add_admission', fetchuser, async (req, res) => {
  try {
    const existingAdmission = await Admission.findOne({ user: req.user.id });

    if (existingAdmission) {
      return res.status(400).json({ enter:existingAdmission.entered,message: "You have already applied for admission." });
    }

    const {
      full_name,
      date_of_birth,
      gender,
      nationality,
      religion,
      category,
      physically,
      blood,
      mobile,
      email,
      father_name,
      father_occupation,
      mother_name,
      mother_occupation,
      annual_income,
      current_add,
      parent_number,
      parent_email,
      image_url,
      state,
      ten_school_name,
      ten_year_passing,
      ten_maxmarks,
      ten_obtained_marks,
      ten_percentage,
      ten_subject1,
      ten_subject2,
      ten_subject3,
      ten_subject4,
      ten_subject5,
      ten_subject6,
      ten_image_url,
      tenth_certificate,
      two_school_name,
      two_year_passed,
      two_max_marks,
      two_obtained_marks,
      two_percentage,
      two_image_url,
      ug_combination,
      ug_course,
      pu_course,
      ten_subject1_name,
      ten_subject2_name,
      ten_subject3_name,
      ten_subject4_name,
      ten_subject5_name,
      ten_subject6_name,
      status
    } = req.body;

    const newAdmission = new Admission({
      user: req.user.id,
      full_name,
      date_of_birth,
      gender,
      nationality,
      religion,
      category,
      physically,
      blood,
      mobile,
      email,
      father_name,
      father_occupation,
      mother_name,
      mother_occupation,
      annual_income,
      current_add,
      parent_number,
      parent_email,
      image_url,
      state,
      ten_school_name,
      ten_year_passing,
      ten_maxmarks,
      ten_obtained_marks,
      ten_percentage,
      ten_subject1,
      ten_subject2,
      ten_subject3,
      ten_subject4,
      ten_subject5,
      ten_subject6,
      ten_image_url,
      tenth_certificate,
      two_school_name,
      two_year_passed,
      two_max_marks,
      two_obtained_marks,
      two_percentage,
      two_image_url,
      ug_combination,
      ug_course,
      pu_course,
      ten_subject1_name,
      ten_subject2_name,
      ten_subject3_name,
      ten_subject4_name,
      ten_subject5_name,
      ten_subject6_name,
      entered: true,
      status:false,
    });

    await newAdmission.save();
    res.status(201).json(newAdmission);
  } catch (error) {
    console.error('Error in add_admission:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/fetchalladmission', fetchuser, async (req, res) => { 
  try {
    const admissions = await Admission.find({ user: req.user.id });
    res.json(admissions);
  } catch (error) {
    console.error("Error fetching admissions:", error.message);
    res.status(500).send("Server Error");
  }
});


// fetch all user for admin with out veri
router.get('/fetchalladmission_for_admin',  async (req, res) => { 
  try {
    const admissions = await Admission.find({});

    res.json(admissions);
  } catch (error) {
    console.error("Error fetching admissions:", error.message);
    res.status(500).send("Server Error");
  }
});
// fetch only one user for admin with out veri
router.get('/show_user_ids',  async (req, res) => { 
  try {
    const admissions = await Admission.find({});
    const userIds = admissions.map(admission => admission.user);
    res.json(userIds);



  } catch (error) {
    console.error("Error fetching admissions:", error.message);
    res.status(500).send("Server Error");
  }
});



// to get user details after clicking verification buttonn and use marks detail for verifi

router.get('/fetchadmissionbyuserid/:userId', async (req, res) => { 
  try {
    const admission = await Admission.findOne({ user: req.params.userId });
    if (!admission) {
      return res.status(404).json({ msg: 'Admission not found' });
    }
    res.json({ ten_percentage: admission.ten_percentage });
  } catch (error) {
    console.error("Error fetching admission:", error.message);
    res.status(500).send("Server Error");
  }
});
 



module.exports = router;
