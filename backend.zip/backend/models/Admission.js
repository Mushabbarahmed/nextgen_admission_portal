const mongoose=require('mongoose')
const { Schema } = mongoose;
const AdmissionSchema = new Schema({
    user:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'user'
    },
full_name:{
type:String,required:true},
status:{
    type:String,required:false},



date_of_birth:{
type:Date,
default:Date.now(),required:true},
gender:{
type:String,required:true},
state:{
    type:String
    ,required:true
},








nationality:{
type:String,required:true
},
entered:{
    type:String,required:false,
    },
religion:{
type:String,required:true
},
category:{
type:String,required:true
},
physically:{
type:String,required:true
},
blood:{
type:String,required:true
},
mobile:{
type:Number,required:true
},

    
email:{
type:String,required:true
},
father_name:{
type:String,required:true
},
father_occupation:{
type:String,required:true
},

mother_name:{
type:String,required:true
},
mother_occupation:{
type:String,required:true
},
annual_income:{
type:Number,required:true
},

current_add:{
type:String,required:true
    },
parent_number:{
type:Number,required:true
},

parent_email:{
type:String,required:true
        },
image_url:{
    type:String,required:false},


ten_school_name:{
    type:String,
    required:false,
},

ten_year_passing:{
    type:Number,
    required:false,
},
ten_maxmarks:{
    type:Number,
    required:false,
},
ten_obtained_marks:{
    type:Number,
    required:false,
},
ten_percentage:{
    type:Number,
    required:false,
},
ten_subject1:{
    type:Number,
    required:false,
},
ten_subject2:{
    type:Number,
    required:false,
},
ten_subject3:{
    type:Number,
    required:false,
},
ten_subject4:{
    type:Number,
    required:false,
},
ten_subject5:{
    type:Number,
    required:false,
},
ten_subject6:{
    type:Number,
    required:false,
},

ten_subject1_name:{
    type:String,
    required:false,
},
ten_subject2_name:{
    type:String,
    required:false,
},
ten_subject3_name:{
    type:String,
    required:false,
},
ten_subject4_name:{
    type:String,
    required:false,
},
ten_subject5_name:{
    type:String,
    required:false,
},
ten_subject6_name:{
    type:String,
    required:false,
},


ten_image_url:{
    type:String,required:false,
},

pu_course:{
    type:String,
    required:false,
},

two_school_name:{
    type:String,required:false,
},
two_year_passed:{
            type:Number,
        required:false,
    },
two_maxmarks:{
    type:Number,
    required:false,
},
two_obtained_marks:{
    type:Number,
    required:false,
},
two_percentage:{
    type:Number,
    required:false,
},

two_image_url:{
    type:String,required:false,
},


ug_combination:{
    type:String,
    required:false,
},

ug_course:{
    type:String,
    required:false,
},


}

        

);


const User=mongoose.model('Admission',AdmissionSchema)
// User.createIndexes()
module.exports=User