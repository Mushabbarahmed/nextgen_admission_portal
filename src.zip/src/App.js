import './App.css';
import React from 'react';
import Signup from './components/Signup';


import {
  BrowserRouter as Router,
  Route,
  Routes,
  Link
} from "react-router-dom";
import Navbar from './components/Navbar';
import Admission_com from './components/Admission_com';
import Home from './components/Home';
import Login from './components/Login';
import Verify from './components/Verify';
import Keer from './components/Keer';
import UgDocuments from './components/Ug_documents';
import Pu_documents from './components/Pu_documents';
import Track from './components/Track';
import Chart from './components/Chart';
import Payment from './components/Payment';

function App() {
  return (
   <><Router>
   {/* <div className="App"> */}
    {/* <Navbar/> */}
    <Navbar/>
    {/* <Signup/> */}
   
    <div style={{margin:20}}></div>
   <Routes>

   <Route path="/signup" element={<Signup/>} />
   <Route path="/" element={<Login/>} />
   <Route path="/home" element={<Home/>} />
   <Route path="/admission" element={<Admission_com/>} />
   <Route path="/ug_document" element={<UgDocuments/>} />
   <Route path="/pu_document" element={<Pu_documents  /> } />
   <Route path="/track" element={<Track/>} />
   <Route path="/chart" element={<Chart/>} />

   <Route path="/verify" element={<Verify/>} />
   <Route path="/keer" element={<Keer/>} />
   <Route path="/payment" element={<Payment/>} />


   </Routes>

   </Router>
   {/* </div> */}
   </>
  );
}

export default App;
