import React from 'react';
import { useState } from "react"
import { useNavigate } from 'react-router-dom';

export default function Signup() {
  let navigate = useNavigate();
  const [note,setNote]=useState({emailid:"",password:"",name:""})
  const handleSubmit=async(e)=>{
      e.preventDefault()
      const response = await fetch(`http://localhost:5000/api/auth/`, {
          method: "POST", 
              headers: {
               
            
                  "Content-Type": "application/json",
          }
          ,body:JSON.stringify({name:note.name,password:note.password,email:note.emailid})
        });
        const json= await response.json(); 
        await localStorage.setItem('token',json.token)
        console.log(json.token)
        await  navigate('/home')
      }
      const onChange=(e)=>{
        setNote({...note,[e.target.name]:e.target.value})
        console.log(note)
  
    }
  return (
    <div>
      <section className="h-100">
        <div className="container py-5 h-100" style={{marginTop:20}}>
          <div className="row d-flex justify-content-center align-items-center h-100" style={{marginTop:20}}>
            <div className="col col-xl-4">
              <div className="card card-login">
                <div className="card-body p-md-5 text-black">
                  <h3 className="mb-5 text-uppercase text-center">Sign Up</h3>
                  <form onSubmit={handleSubmit}>
                    <div className="form-outline mb-4">
                      <input type="text" id="name" className="form-control form-control-lg" name="name" onChange={onChange}/>
                    <label className="form-label" htmlFor="name">Name</label>
                    </div>
                    <div className="form-outline mb-4">
                      <input type="email" id="emailid" onChange={onChange} name="emailid" aria-describedby="emailHelp" className="form-control form-control-lg" />
                      <label className="form-label" htmlFor="gmail">Gmail</label>
                    </div>
                    <div className="form-outline mb-4">
                      <input type="password"  className="form-control form-control-lg" id="password"  name="password" onChange={onChange} />
                      <label className="form-label" htmlFor="password">Password</label>
                    </div>
                    <div className="d-flex justify-content-center">
                      <button type="submit" className="btn btn-primary btn-lg">Sign Up</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
