import React from 'react'
import './track.css'; // Import the CSS file
export default function Track() {
  return (
    <>
    <div class="container mt-5" style={{marginTop:120}}>

        <h1 class="text-center mb-4"style={{marginTop:120}}><b>Application Tracking Progress</b></h1>
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="progress-container">
                    <div class="step">
                        <div class="step-icon">
                            <i class="fas fa-clipboard-list"></i>
                        </div>
                        <div class="step-details">
                            <h5>Application Submitted</h5>
                            
                        </div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar" style={{width: 25}}></div>
                    </div>
                    <div class="step">
                        <div class="step-icon">
                            <i class="fas fa-hourglass-half"></i>
                        </div>
                        <div class="step-details">
                            <h5>Under Review</h5>
                            
                        </div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar" style={{width: 50}}></div>
                    </div>
                    <div class="step">
                        <div class="step-icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="step-details">
                            <h5>Interview Scheduled</h5>
                           
                        </div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar" style={{width: 75}}></div>
                    </div>
                    <div class="step">
                        <div class="step-icon">
                            <i class="fas fa-thumbs-up"></i>
                        </div>
                        <div class="step-details">
                            <h5>Payment Status</h5>
                            
                        </div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar" style={{width: 75}}></div>
                    </div>
                    <div class="step">
                        <div class="step-icon">
                            <i class="fas fa-thumbs-up"></i>
                        </div>
                        <div class="step-details">
                            <h5>Application Verified</h5>
                            
                        </div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar" style={{width: 100}}></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    </>
  )
}
