import React, {useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
export default function UgDocuments() {
  let navigate = useNavigate();
  const [formData, setFormData] = useState({
    full_name: "",
    date_of_birth: "",
    gender: "",
    nationality: "",
    religion: "",
    category: "",
    state:"",
    physically: "",
    blood: "",
    mobile: "",
    email: "",
    father_name: "",
    father_occupation: "",
    mother_name: "",
    mother_occupation: "",
    annual_income: "",
    current_add: "",
    parent_number: "",
    parent_email: "",
    image_url: "",

    ten_school_name: '',
    ten_year_passing: '',
    ten_maxmarks: '',
    ten_obtained_marks: '',
    ten_percentage: '',
    ten_subject1:'' ,
    ten_subject2:'' ,
    ten_subject3:'' ,
    ten_subject4:'' ,
    ten_subject5:'' ,
    ten_subject6:'' ,
    ten_image_url:'',
    tenth_certificate: '',
    two_school_name:'',
    two_year_passed: '',
    two_max_marks: '',
    two_obtained_marks: '',
    two_percentage: '',
    two_image_url: '',
    ug_combination: '',
    ug_course: '',
  });


  const [image, setImage] = useState(null);
  const [timage, setTimage] = useState(null);
  const [twoimage, setTwoimage] = useState(null);
  const [imageUrl, setImageUrl] = useState(null); // State to store fetched image URL
  const [cloudinaryPublicId, setCloudinaryPublicId] = useState(null); // State to store cloudinary public id

  const uploadPreset = 'keerthana'; // Replace with your actual upload preset name
  const cloudName = 'dpmjqrygj'; // Replace with your Cloudinary cloud name


  

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    setImage(file);
  }
  const handletenImageChange = (e) => {
    const file = e.target.files[0];
    setTimage(file);
  }
  const handleTwoimageChange = (e) => {
    const file = e.target.files[0];
    setTwoimage(file);
  }
  useEffect(()=>{
    console.log(localStorage)
    if(localStorage.getItem('token')){
      navigate('/ug_document')
        }
  else{
    navigate('/')
  }
  },[])
  const handleChange = (e) => {
    const { name, value, files } = e.target;
    setFormData({
      ...formData,
      // [e.target.name]: e.target.value
      [name]: files ? files[0] : value
    });
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
  
    if (!image && !timage && !twoimage) {
      console.log("No image selected");
      return;
    }
  
    const formDataImage = new FormData();
    formDataImage.append("file", image);
    formDataImage.append("upload_preset", uploadPreset);
    formDataImage.append("cloud_name", cloudName);


    const formDataImage1 = new FormData();
    formDataImage1.append("file", timage);
    formDataImage1.append("upload_preset", uploadPreset);
    formDataImage1.append("cloud_name", cloudName);
   
    const formDataImage2 = new FormData();
    formDataImage2.append("file", twoimage);


    formDataImage2.append("upload_preset", uploadPreset);
    formDataImage2.append("cloud_name", cloudName);


    
    
  
    try {
      const imageUploadResponse = await fetch(`https://api.cloudinary.com/v1_1/${cloudName}/image/upload`, {
        method: "POST",
        body: formDataImage
      });
      const imageUploadResponse1 = await fetch(`https://api.cloudinary.com/v1_1/${cloudName}/image/upload`, {
        method: "POST",
        body: formDataImage1
      });
      const imageUploadResponse2 = await fetch(`https://api.cloudinary.com/v1_1/${cloudName}/image/upload`, {
        method: "POST",
        body: formDataImage2
      });
  
      if (!imageUploadResponse.ok) {
        throw new Error('Network response was not ok');
      }
      //profilephoto
      const imageData = await imageUploadResponse.json();
      console.log("Upload successful:", imageData);
      const publicId = imageData.public_id;
      setCloudinaryPublicId(publicId);
  
      const imageUrl = `https://res.cloudinary.com/${cloudName}/image/upload/${publicId}`;
      setImageUrl(imageUrl);
      //two marks photo
      const imageData2 = await imageUploadResponse2.json();
      console.log("twelth marks card Upload successful:", imageData2);
      const publicId2 = imageData2.public_id;
      setCloudinaryPublicId(publicId2);
  
      const twoimageUrl = `https://res.cloudinary.com/${cloudName}/image/upload/${publicId2}`;
      setImageUrl(twoimageUrl);

      //temth photo
      const imageData1 = await imageUploadResponse1.json();
      console.log("tenth marks card Upload successful:", imageData1);
      const publicId1 = imageData1.public_id;
      setCloudinaryPublicId(publicId1);
  
      const timageUrl = `https://res.cloudinary.com/${cloudName}/image/upload/${publicId1}`;
      setImageUrl(timageUrl);

      

      // Update formData with the image URL
      const updatedFormData = {
        ...formData,
        image_url: imageUrl,
        ten_image_url:timageUrl,
        two_image_url:twoimageUrl
      };
  
      console.log("Image URL setting done!!");
  
      const response = await fetch(`http://localhost:5000/api/admissions/add_admission`, {
        method: "POST",
        headers: {
          "auth-token": localStorage.getItem('token'),
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updatedFormData)
      });
  
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
  
      const json = await response.json();
      console.log("Form submission successful:", json);
  
      await navigate('/home');
    } catch (error) {
      console.error("Error:", error);
      // Handle errors here, e.g., show error message to the user
    }
  };
  
  return (
    <section className="h-100">
      <div className="container py-5 h-100">
        <div className="row d-flex justify-content-center align-items-center h-100">
          <div className="col">
            <div className="card card-registration my-4">
              <div className="card-body p-md-5 text-black">
                <h3 className="mb-5 text-uppercase text-center">UG Admissions Student Registration Form</h3>

                <form onSubmit={handleSubmit}>
                    <h3 className="mb-5 text-uppercase text-center">Student Registration Form</h3>

                    {/* Personal Details */}
                    <h4 className="mb-3">Personal Details</h4>
                    <div className="row">
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="text" id="full_name" name="full_name" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="full_name">Full Name</label>
                        </div>
                      </div>
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="date" id="date_of_birth" name="date_of_birth" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="date_of_birth">Date of Birth</label>
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="text" id="gender" name="gender" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="gender">Gender</label>
                        </div>
                      </div>
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="text" id="nationality" name="nationality" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="nationality">Nationality</label>
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="text" id="religion" name="religion" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="religion">Religion</label>
                        </div>
                      </div>
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="text" id="category" name="category" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="category">Category</label>
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="text" id="physically" name="physically" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="physically">Physically Challenged (Yes/No)</label>
                        </div>
                      </div>
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="text" id="blood" name="blood" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="blood">Blood Group</label>
                        </div>
                      </div>
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="text" id="state" name="state" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="blood">State</label>
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="text" id="mobile" name="mobile" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="mobile">Mobile Number</label>
                        </div>
                      </div>
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="email" id="email" name="email" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="email">Email ID</label>
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-md-12 mb-4">
                        <div className="form-outline">
                          {/* <input type="file" id="image_url" name="image_url" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="image_url">Photo</label> */}
                        <input type="file" onChange={handleImageChange} />
                        {/* <button onClick={submitImage}>Upload</button> */}
                        
                        </div>
                      </div>
                    </div>

                    {/* Parents Details */}
                    <h4 className="mb-3 mt-4">Parents Details</h4>
                    <div className="row">
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="text" id="father_name" name="father_name" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="father_name">Father's Name</label>
                        </div>
                      </div>
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="text" id="father_occupation" name="father_occupation" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="father_occupation">Father's Occupation</label>
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="text" id="mother_name" name="mother_name" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="mother_name">Mother's Name</label>
                        </div>
                      </div>
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="text" id="mother_occupation" name="mother_occupation" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="mother_occupation">Mother's Occupation</label>
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="number" id="annual_income" name="annual_income" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="annual_income">Annual Income</label>
                        </div>
                      </div>
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="text" id="current_add" name="current_add" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="current_add">Current Address (State, District, Country)</label>
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="text" id="parent_number" name="parent_number" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="parent_number">Parent's Mobile Number</label>
                        </div>
                      </div>
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <input type="email" id="parent_email" name="parent_email" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="parent_email">Parent's Email ID</label>
                        </div>
                      </div>
                    </div>

                  <h4 className="mb-3">10th Standard Details</h4>
                  <div className="row">
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="text" id="ten_school_name" name="ten_school_name" className="form-control form-control-lg" onChange={handleChange} />
                        <label className="form-label" htmlFor="tenth_school">School Name</label>
                      </div>
                    </div>
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="text" id="ten_year_passing" name="ten_year_passing" className="form-control form-control-lg" onChange={handleChange} />
                        <label className="form-label" htmlFor="tenth_year">Year of Passing</label>
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="text"  className="form-control form-control-lg"   />
                        <label className="form-label" htmlFor="tenth_board">Board of Education</label>
                      </div>
                    </div>
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="number" id="ten_maxmarks" name="ten_maxmarks" className="form-control form-control-lg"  onChange={handleChange} />
                        <label className="form-label" htmlFor="tenth_max_marks">Maximum Marks</label>
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="number" id="ten_obtained_marks" name="ten_obtained_marks" className="form-control form-control-lg"  onChange={handleChange} />
                        <label className="form-label" htmlFor="tenth_min_marks">Marks Obtained</label>
                      </div>
                    </div>
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="number" id="tenth_percentage" name="tenth_percentage" className="form-control form-control-lg"  onChange={handleChange} />
                        <label className="form-label" htmlFor="tenth_percentage">Percentage</label>
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="number" id="ten_subject1" name="ten_subject1" className="form-control form-control-lg"  onChange={handleChange} />
                        <label className="form-label" htmlFor="tenth_min_marks">Subject1</label>
                      </div>
                    </div>
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="number" id="ten_subject2" name="ten_subject2" className="form-control form-control-lg"  onChange={handleChange} />
                        <label className="form-label" htmlFor="tenth_min_marks">Subject2</label>
                      </div>
                    </div>
                    </div>
                    <div className="row">
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="number" id="ten_subject3" name="ten_subject3" className="form-control form-control-lg"  onChange={handleChange} />
                        <label className="form-label" htmlFor="tenth_min_marks">Subject3</label>
                      </div>
                    </div>
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="number" id="ten_subject4" name="ten_subject4" className="form-control form-control-lg"  onChange={handleChange} />
                        <label className="form-label" htmlFor="tenth_min_marks">Subject4</label>
                      </div>
                    </div>
                    </div>
                    <div className="row">
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="number" id="ten_subject5" name="ten_subject5" className="form-control form-control-lg"  onChange={handleChange} />
                        <label className="form-label" htmlFor="tenth_min_marks">Subject5</label>
                      </div>
                    </div>
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="number" id="ten_subject6" name="ten_subject6" className="form-control form-control-lg"  onChange={handleChange} />
                        <label className="form-label" htmlFor="tenth_min_marks">Subjec62</label>
                      </div>
                    </div>
                    </div>

                  

                 




                  
                    <div className="row">
                      <div className="col-md-12 mb-4">
                        <div className="form-outline">
                          {/* <input type="file" id="image_url" name="image_url" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="image_url">Photo</label> */}
                        <input type="file" onChange={handletenImageChange} />
                        {/* <button onClick={submitImage}>Upload</button> */}
                        
                        </div>
                      </div>
                    </div>
                    
                  <h4 className="mb-3">12th Standard Details</h4>
                  <div className="row">
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="text" id="two_school_name" name="two_school_name" className="form-control form-control-lg"  onChange={handleChange} />
                        <label className="form-label" htmlFor="twelfth_school">School Name</label>
                      </div>
                    </div>
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="text" id="two_year_passed"  name="two_year_passed"  className="form-control form-control-lg"  onChange={handleChange} />
                        <label className="form-label" htmlFor="twelfth_year">Year of Passing</label>
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="text"   className="form-control form-control-lg"   />
                        <label className="form-label" htmlFor="twelfth_board">Board of Education</label>
                      </div>
                    </div>
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="number" id="two_max_marks" name="two_max_marks"  className="form-control form-control-lg"  onChange={handleChange} />
                        <label className="form-label" htmlFor="twelfth_max_marks">Maximum Marks</label>
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="number" id="two_obtained_marks" name="two_obtained_marks"  className="form-control form-control-lg"   onChange={handleChange} />
                        <label className="form-label" htmlFor="twelfth_min_marks">Marks Obtained</label>
                      </div>
                    </div>
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="number" id="two_percentage" name="two_percentage" className="form-control form-control-lg"  onChange={handleChange} />
                        <label className="form-label" htmlFor="twelfth_percentage">Percentage</label>
                      </div>
                    </div>
                  </div>
                  
                  
                  <div className="row">
                      <div className="col-md-12 mb-4">
                        <div className="form-outline">
                          {/* <input type="file" id="image_url" name="image_url" className="form-control form-control-lg" onChange={handleChange} />
                          <label className="form-label" htmlFor="image_url">Photo</label> */}
                        <input type="file" onChange={handleTwoimageChange} />
                        {/* <button onClick={submitImage}>Upload</button> */}
                        
                        </div>
                      </div>
                    </div>

                  

                  <h4 className="mb-3">Declaration</h4>
                  <div className="row">
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <textarea  className="form-control form-control-lg" ></textarea>
                        <label className="form-label" htmlFor="declaration">Declaration</label>
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="date"  className="form-control form-control-lg"  />
                        <label className="form-label" htmlFor="declarationDate">Date</label>
                      </div>
                    </div>
                    <div className="col-md-6 mb-4">
                      <div className="form-outline">
                        <input type="text" className="form-control form-control-lg"  />
                        <label className="form-label" htmlFor="declarationPlace">Place</label>
                      </div>
                    </div>
                  </div>

                  <div className="d-flex justify-content-end pt-3">
                    <button type="button" className="btn btn-light btn-lg">Reset all</button>
                    <button type="submit" className="btn btn-warning btn-lg ms-2">Submit form</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}



