// import React from 'react'
// import { Link} from 'react-router-dom';
// import { useNavigate } from 'react-router-dom';
// // import "./Navbar.css"

// // import { NavLink } from 'react-router-dom'
// export default function Navbar(){
//   const navigate=useNavigate()
//   const handlelogout=()=>{
//     localStorage.removeItem('token')
//     navigate('/')
// }
//   return (
//     <nav class="navbar navbar-expand-lg bg-body-dark">
//   <div class="container-fluid">
//     <a class="navbar-brand" href="/" style={{fontWeight:'bold', fontSize:'28px'}}>NEXT GEN_AI</a>
//     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
//       <span class="navbar-toggler-icon"></span>
//     </button>
//     <div class="collapse navbar-collapse" id="navbarSupportedContent">
//       <ul class="navbar-nav me-auto mb-2 mb-lg-0">
//         <li class="nav-item">
//           <a class="nav-link active" aria-current="page" href="/home" style={{ fontSize:'20px' ,color:'white',fontWeight:'bold'}}>Home</a>
//         </li>
//         <li class="nav-item">
//           <a class="nav-link" href="/admission"style={{ fontSize:'20px',color:'white',fontWeight:'bold'}}>PG form</a>
//         </li>
//         <li class="nav-item">
//           <a class="nav-link" href="/pu_document" style={{ fontSize:'20px',color:'white',fontWeight:'bold'}}>PU form</a>
//         </li>
//         <li class="nav-item">
//           <a class="nav-link" href="/ug_document" style={{ fontSize:'20px',color:'white',fontWeight:'bold'}}>UG form</a>
//         </li>
//         <li class="nav-item">
//           <a class="nav-link" href="/track" style={{ fontSize:'20px',color:'white',fontWeight:'bold'}}>Track</a>
//         </li>
       
        
//       </ul>
    


//       {!localStorage.getItem('token')?<>
//         <Link class="btn btn-outline-success mx-2" role="button" to="/" style={{ fontWeight:'bold',color:'white', borderColor:'black',border:'2px solid black',backgroundColor:'black'}}> login</Link>
//         <Link class="btn btn-outline-success mx-2" role="button" to="/signup"style={{ fontWeight:'bold',color:'white', borderColor:'black',border:'2px solid black',backgroundColor:'black'}}>signup</Link>
//         </>:<form class="d-flex" role="search">
//       <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search"/>
//       <button class="btn btn-outline-success" type="submit">Search</button>
//     <button class="btn btn-outline-success mx-2" onClick={handlelogout}> logout</button></form>}
//     </div>
//   </div>
// // </nav>
// // <header className="header-area header-sticky">
// //       <div className="container">
// //         <div className="row">
// //           <div className="col-12">
// //             <nav className="main-nav navbar navbar-expand-lg bg-body-dark">
// //               {/* Logo */}
// //               <a href="/" className="logo navbar-brand" style={{ fontWeight: 'bold', fontSize: '28px' }}>
// //                 NEXT GEN_AI
// //               </a>
// //               {/* Search Input */}
// //               <div className="search-input d-lg-none">
// //                 <form id="search" action="#">
// //                   <input type="text" placeholder="Type Something" id="searchText" name="searchKeyword" />
// //                   <i className="fa fa-search"></i>
// //                 </form>
// //               </div>
// //               {/* Navbar Toggle Button */}
// //               <button
// //                 className="navbar-toggler"
// //                 type="button"
// //                 data-bs-toggle="collapse"
// //                 data-bs-target="#navbarSupportedContent"
// //                 aria-controls="navbarSupportedContent"
// //                 aria-expanded="false"
// //                 aria-label="Toggle navigation"
// //               >
// //                 <span className="navbar-toggler-icon"></span>
// //               </button>
// //               {/* Navbar Links */}
// //               <div className="collapse navbar-collapse" id="navbarSupportedContent">
// //                 <ul className="navbar-nav me-auto mb-2 mb-lg-0">
// //                   <li className="nav-item">
// //                     <Link className="nav-link active" aria-current="page" to="/home" style={{ fontSize: '20px', color: 'white', fontWeight: 'bold' }}>
// //                       Home
// //                     </Link>
// //                   </li>
// //                   <li className="nav-item">
// //                     <Link className="nav-link" to="/admission" style={{ fontSize: '20px', color: 'white', fontWeight: 'bold' }}>
// //                       PG Form
// //                     </Link>
// //                   </li>
// //                   <li className="nav-item">
// //                     <Link className="nav-link" to="/pu_document" style={{ fontSize: '20px', color: 'white', fontWeight: 'bold' }}>
// //                       PU Form
// //                     </Link>
// //                   </li>
// //                   <li className="nav-item">
// //                     <Link className="nav-link" to="/ug_document" style={{ fontSize: '20px', color: 'white', fontWeight: 'bold' }}>
// //                       UG Form
// //                     </Link>
// //                   </li>
// //                   <li className="nav-item">
// //                     <Link className="nav-link" to="/track" style={{ fontSize: '20px', color: 'white', fontWeight: 'bold' }}>
// //                       Track
// //                     </Link>
// //                   </li>
// //                 </ul>
// //                 {!localStorage.getItem('token')? (
// //                   <>
// //                     <Link className="btn btn-outline-success mx-2" role="button" to="/login" style={{ fontWeight: 'bold', color: 'white', borderColor: 'black', border: '2px solid black', backgroundColor: 'black' }}>
// //                       Login
// //                     </Link>
// //                     <Link className="btn btn-outline-success mx-2" role="button" to="/signup" style={{ fontWeight: 'bold', color: 'white', borderColor: 'black', border: '2px solid black', backgroundColor: 'black' }}>
// //                       Sign Up
// //                     </Link>
// //                   </>
// //                 ) : (
// //                   <form className="d-flex" role="search">
// //                     <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
// //                     <button className="btn btn-outline-success" type="submit">
// //                       Search
// //                     </button>
// //                     <button className="btn btn-outline-success mx-2" onClick={handlelogout}>
// //                       Logout
// //                     </button>
// //                   </form>
// //                 )}
// //               </div>
// //             </nav>
// //           </div>
// //         </div>
// //       </div>
// //     </header>
//   )
// }


import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Navbar.css'; // Add any custom styles here

export default function Navbar() {
  const navigate = useNavigate();
  const [searchText, setSearchText] = useState('');

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/');
  };

  const handleSearch = (e) => {
    e.preventDefault();
    // Implement search functionality here
    console.log(searchText);
  };

  return (
    <header className="header-area header-sticky">
      <div className="container">
        <div className="row">
          <div className="col-12">
            <nav className="main-nav" style={{margin:20}}>
              <a href="/" className="logo">
                <h6>Next-Gen</h6>
              </a>
              <div className="search-input">
                <form id="search" onSubmit={handleSearch}>
                  <input
                    type="text"
                    placeholder="Type Something"
                    id="searchText"
                    name="searchKeyword"
                    value={searchText}
                    onChange={(e) => setSearchText(e.target.value)}
                  />
                  <i className="fa fa-search"></i>
                </form>
              </div>
              <ul className="nav">
                <li className="scroll-to-section">
                  <Link to="/home" className="active">Home</Link>
                </li>
                <li className="scroll-to-section">
                  <a href="#services">About</a>
                </li>
                <li className="scroll-to-section">
                  <a href="#courses">Courses</a>
                </li>
                {!localStorage.getItem('token') ? (
                  <>
                    <li className="scroll-to-section">
                      <Link to="/">Login</Link>
                    </li>
                    <li className="scroll-to-section">
                      <Link to="/signup">Sign Up</Link>
                    </li>
                  </>
                ) : (
                  <li className="scroll-to-section">
                    <button className="btn btn-outline-success" type="button" onClick={handleLogout}>Logout</button>
                  </li>
                )}
              </ul>
            </nav >
          </div>
        </div>
      </div>
    </header>
  );
}
