import React from 'react'
import { useState ,useEffect} from "react"
import { useNavigate } from 'react-router-dom';

export default function Login() {
    console.log("localstorage",localStorage)
    useEffect(()=>{
    localStorage.removeItem('token')
       
      },[])
    let navigate = useNavigate();
    const [note,setNote]=useState({emailid:"",password:""})
   
   
    const handleSubmit=async(e)=>{
        e.preventDefault()
        const response = await fetch(`http://localhost:5000/api/auth/login`, {
            method: "POST", 
                headers: {
                 
              
                    "Content-Type": "application/json",
            }
            ,body:JSON.stringify({email:note.emailid,password:note.password})
          });

          const json= await response.json(); 
          if (json.success){
          
            await localStorage.setItem('token',json.token)
            await  navigate('/home')
        }
        else{
            localStorage.clear()
        //    props.showalert("WRONG","Inavlid password")
          }
        }

        const onChange=(e)=>{
            setNote({...note,[e.target.name]:e.target.value})
            console.log(note)
    
        }

  return (
    <div>
    <section className="h-100">
      <div className="container py-5 h-50" style={{height:50}}>
        <div className="row d-flex justify-content-center align-items-center h-100" style={{marginTop:30}}>
          <div className="col col-xl-4">
            <div className="card card-login">
              <div className="card-body p-md-5 text-black">
                <h3 className="mb-5 text-uppercase text-center">Sign Up</h3>
                <form onSubmit={handleSubmit}>
                
                  <div className="form-outline mb-4">
                    <input type="email" id="emailid" onChange={onChange} name="emailid" aria-describedby="emailHelp" className="form-control form-control-lg" />
                    <label className="form-label" htmlFor="gmail">Gmail</label>
                  </div>
                  <div className="form-outline mb-4">
                    <input type="password"  className="form-control form-control-lg" id="password"  name="password" onChange={onChange} />
                    <label className="form-label" htmlFor="password">Password</label>
                  </div>
                  <div className="d-flex justify-content-center">
                    <button type="submit" className="btn btn-primary btn-lg">Login</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  )
}
