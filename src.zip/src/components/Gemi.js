const { VertexAI } = require('@google-cloud/vertexai');
const axios = require('axios');

async function getBase64(url) {
  const image = await axios.get(url, { responseType: 'arraybuffer' });
  return Buffer.from(image.data).toString('base64');
}

/**
 * TODO(developer): Update these variables before running the sample.
 */
async function sendMultiModalPromptWithImage(
  projectId = 'PROJECT_ID',
  location = 'us-central1',
  model = 'gemini-1.5-flash-001'
) {
  // For images, the SDK supports base64 strings
  const imageBase64 = await getBase64('https://res.cloudinary.com/dpmjqrygj/image/upload/tcsnv7ppsymasgldfea0');

  // Initialize Vertex with your Cloud project and location
  const vertexAI = new VertexAI({ project: projectId, location: location });

  const generativeVisionModel = vertexAI.getGenerativeModel({
    model: model,
  });

  // Pass multimodal prompt with a single text query
  const request = {
    contents: [
      {
        role: 'user',
        parts: [
          {
            inlineData: {
              data: imageBase64,
              mimeType: 'image/jpeg', // or 'image/png' based on your image type
            },
          },
          {
            text: 'display all subject marks and their name in this format subject name :total marks obtained', // Add your text query here
          },
        ],
      },
    ],
  };

  // Create the response
  const response = await generativeVisionModel.generateContent(request);
  // Wait for the response to complete
  const aggregatedResponse = await response.response;
  // Select the text from the response
  const fullTextResponse = aggregatedResponse.candidates[0].content.parts[0].text;

  console.log(fullTextResponse);
}

// Run the function with your project details
sendMultiModalPromptWithImage('aqueous-aileron-430419-e9', 'us-central1', 'gemini-1.5-flash-001');
