import React,{ useEffect} from 'react';
import { useNavigate } from 'react-router-dom';

import './Home.css'; // Import the CSS file

export default function Home() {
  let navigate = useNavigate();

  useEffect(()=>{
    console.log(localStorage)
    if(localStorage.getItem('token')){
      navigate('/home')
        }
  else{
    navigate('/')
  }
  },[])
  




  useEffect(() => {
    const filterButtons = document.querySelectorAll('.event_filter a');
    const courses = document.querySelectorAll('.event_outer');

    // Show all courses initially
    courses.forEach(course => {
      course.style.display = 'block';
    });

    filterButtons.forEach(button => {
      button.addEventListener('click', function(event) {
        event.preventDefault();

        const filter = button.getAttribute('data-filter');

        // Remove active class from all buttons
        filterButtons.forEach(btn => btn.classList.remove('is_active'));
        // Add active class to clicked button
        button.classList.add('is_active');

        // Show/hide courses based on filter
        courses.forEach(course => {
          if (filter === '*' || course.classList.contains(filter.slice(1))) {
            course.style.display = 'block';
          } else {
            course.style.display = 'none';
          }
        });
      });
    });
  }, []);

  
  return (
    <div>
      {/* Header Area Start */}
      
      {/* Main Banner */}
      <div className="main-banner" id="top">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <div id="carouselExampleCaptions" className="carousel slide" data-bs-ride="carousel">
                <div className="carousel-inner">
                  <div className="carousel-item active">
                    <img src="assets/images/banner-item-01.jpg" className="d-block w-100" alt="Admission Process" />
                    <div className="carousel-caption d-none d-md-block">
                      <span className="category">Admission Process</span><br/><br/><br/>
                      <h2>Join Our Institution and Shape Your Future</h2><br/><br/>
                      <p>Our streamlined admission process ensures you can easily apply and get started on your educational journey.</p>
                    </div>
                  </div>
                  {/* Add more carousel items as needed */}
                </div>
                <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                  <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span className="visually-hidden">Previous</span>
                </button>
                <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                  <span className="carousel-control-next-icon" aria-hidden="true"></span>
                  <span className="visually-hidden">Next</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Services Section */}
      <div className="services section" id="services">
        <div className="container">
          <div className="row">
            {/* Service Items */}
            <div className="col-lg-4 col-md-6">
              <div className="service-item">
                <div className="icon">
                  <img src="assets/images/service-01.png" alt="Admission Guidelines" />
                </div>
                <div className="main-content">
                  <h4>Admission Guidelines</h4>
                  <p>Find detailed guidelines and requirements for applying to our college, including eligibility criteria and necessary documents.</p>
                  <div className="main-button">
                    <a href="#">Read More</a>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-4 col-md-6">
              <div className="service-item">
                <div className="icon">
                  <img src="assets/images/service-02.png" alt="Admission Guidelines" />
                </div>
                <div className="main-content">
                  <h4>Admission Guidelines</h4>
                  <p>Find detailed guidelines and requirements for applying to our college, including eligibility criteria and necessary documents.</p>
                  <div className="main-button">
                    <a href="#">Read More</a>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-4 col-md-6">
              <div className="service-item">
                <div className="icon">
                  <img src="assets/images/service-03.png" alt="Admission Guidelines" />
                </div>
                <div className="main-content">
                  <h4>Admission Guidelines</h4>
                  <p>Find detailed guidelines and requirements for applying to our college, including eligibility criteria and necessary documents.</p>
                  <div className="main-button">
                    <a href="#">Read More</a>
                  </div>
                </div>
              </div>
            </div>
            {/* Add more service items as needed */}
          </div>
        </div>
      </div>

      {/* About Us Section */}
      <div className="section about-us">
        <div className="container">
          <div className="row">
            <div className="col-lg-6 offset-lg-1">
              <div className="accordion" id="accordionExample">
                {/* Accordion Items */}
                <div className="accordion-item">
                  <h2 className="accordion-header" id="headingOne">
                    <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                      How to Apply?
                    </button>
                  </h2>
                  <div id="collapseOne" className="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                    <div className="accordion-body">
                      <strong>Step 1:</strong> Visit our website and navigate to the admission section.<br />
                      <strong>Step 2:</strong> Fill out the online application form with your personal and academic details.<br />
                      <strong>Step 3:</strong> Submit the required documents and pay the application fee.<br />
                      <strong>Step 4:</strong> Await confirmation and further instructions from our admissions team.
                    </div>
                  </div>
                </div>
                <div class="accordion-item">
              <h2 class="accordion-header" id="headingThree">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                  Courses Offered
                </button>
              </h2>
              <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  We offer a wide range of courses in various fields including:<br/>
                  <strong>Science and Technology:</strong> Computer Science, Engineering, Biotechnology.<br/>
                  <strong>Business and Management:</strong> Business Administration, Marketing, Finance.<br/>
                  <strong>Arts and Humanities:</strong> Literature, History, Philosophy.<br/>
                  <strong>Health and Medicine:</strong> Nursing, Public Health, Medicine.
                </div>
              </div>
            </div>
                <div class="accordion-item">
              <h2 class="accordion-header" id="headingFour">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                  Student Support Services
                </button>
              </h2>
              <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  We provide extensive support services to ensure your success:<br/>
                  <strong>Academic Advising:</strong> Personalized academic guidance.<br/>
                  <strong>Counseling Services:</strong> Mental health and wellness support.<br/>
                  <strong>Career Services:</strong> Job placement assistance and career counseling.<br/>
                  <strong>Financial Aid:</strong> Scholarships, grants, and financial aid options.
                </div>
              </div>
            </div>
            
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingTwo">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                  Admission Requirements
                </button>
              </h2>
              <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  <strong>Academic Transcripts:</strong> Provide your previous academic records.<br/>
                  <strong>Personal Statement:</strong> Write a personal statement outlining your goals and motivations.<br/>
                  <strong>Letters of Recommendation:</strong> Submit letters of recommendation from teachers or employers.<br/>
                  <strong>Application Fee:</strong> Pay the non-refundable application fee.
                </div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingThree">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                  Courses Offered
                </button>
              </h2>
              <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  We offer a wide range of courses in various fields including:<br/>
                  <strong>Science and Technology:</strong> Computer Science, Engineering, Biotechnology.<br/>
                  <strong>Business and Management:</strong> Business Administration, Marketing, Finance.<br/>
                  <strong>Arts and Humanities:</strong> Literature, History, Philosophy.<br/>
                  <strong>Health and Medicine:</strong> Nursing, Public Health, Medicine.
                </div>
              </div>
            </div>


                
                
                {/* Add more accordion items as needed */}
              </div>
            </div>
            <div className="col-lg-5 align-self-center">
              <div className="section-heading">
                <h6>About Us</h6>
                <h2>What makes us the best choice for your educational journey?</h2>
                <p>Join us and discover why we are the preferred choice for students seeking a comprehensive and engaging educational experience.</p>
                <div className="main-button">
                  <a href="#">Discover More</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    
      {/* Courses Section */}
      <section className="section courses" id="courses">
        <div className="container">
          <div className="row">
            <div className="col-lg-12 text-center">
              <div className="section-heading">
                <h2 style={{ color: '#97569a' }}>Available Programs</h2>
                <h4>PU, UG, and PG Courses</h4>
              </div>
            </div>
          </div>
          <ul className="event_filter">
            <li>
              <a href="#" data-filter="*">Show All</a>
            </li>
            <li>
              <a href="#" data-filter=".pu">PU Courses</a>
            </li>
            <li>
              <a href="#" data-filter=".ug">Undergraduate Courses</a>
            </li>
            <li>
              <a href="#" data-filter=".pg">Postgraduate Courses</a>
            </li>
          </ul>
          <div className="row event_box">
            {/* Courses Items */}
            <div className="col-lg-4 col-md-6 mb-30 event_outer pu">
              <div className="events_item">
                <div className="thumb">
                  <a href="#"><img src="assets/images/course-01.jpg" alt="PU Science" /></a>
                  <span className="price"><h6>PU</h6></span>
                </div>
                <div className="down-content">
                  <h4>Science</h4>
                  <p>Pre-University Science: Foundation in scientific principles and research.</p>
                  <div className="main-button">
                    <a href="/pu_document">Apply Now</a>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-4 col-md-6 mb-30 event_outer pu">
              <div className="events_item">
                <div className="thumb">
                  <a href="#"><img src="assets/images/course-03.jpg" alt="PU Science" /></a>
                  <span className="price"><h6>PU</h6></span>
                </div>
                <div className="down-content">
                  <h4>Arts</h4>
                  <p>Pre-University Science: Foundation in scientific principles and research.</p>
                  <div className="main-button">
                    <a href="/pu_document">Apply Now</a>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-lg-4 col-md-6 mb-30 event_outer pu">
              <div className="events_item">
                <div className="thumb">
                  <a href="#"><img src="assets/images/course-02.jpg" alt="PU Science" /></a>
                  <span className="price"><h6>PU</h6></span>
                </div>
                <div className="down-content">
                  <h4>Commerce</h4>
                  <p>Pre-University Science: Foundation in scientific principles and research.</p>
                  <div className="main-button">
                    <a href="/pu_document">Apply Now</a>
                  </div>
                </div>
              </div>
            </div>  
            <div class="col-lg-4 col-md-6 mb-30 event_outer ug">
          <div class="events_item">
            <div class="thumb">
              <a href="#"><img src="assets/images/course-04.jpg" alt="B.Com"/></a>
              <span class="price"><h6>UG</h6></span>
              {/* <!-- <span class="category">Undergraduate</span> --> */}
            </div>
            <div class="down-content">
              <h4>B.Com</h4>
              <p>Comprehensive understanding of business and financial principles.</p>
              <div class="main-button">
                <a href="/ug_document">Apply Now</a>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 mb-30 event_outer ug">
          <div class="events_item">
            <div class="thumb">
              <a href="#"><img src="assets/images/course-05.jpg" alt="B.Tech"/></a>
              <span class="price"><h6>UG</h6></span>
              
            </div>
            <div class="down-content">
              <h4>B.Tech</h4>
              <p>Bachelor of Technology: Specialized in various engineering fields.</p>
              <div class="main-button">
                <a href="/ug_document">Apply Now</a>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 mb-30 event_outer ug">
          <div class="events_item">
            <div class="thumb">
              <a href="#"><img src="assets/images/course-06.jpg" alt="BBA"/></a>
              
              <span class="price"><h6>UG</h6></span>
            
            </div>
            <div class="down-content">
              <h4>BBA</h4>
              <p>Bachelor of Business Administration: Prepare for leadership and management roles in business.</p>
              <div class="main-button">
                <a href="/ug_document">Apply Now</a>
              </div>
            </div>
          </div>
        </div>
        
        {/* <!-- Postgraduate Programs --> */}
        <div class="col-lg-4 col-md-6 mb-30 event_outer pg">
          <div class="events_item">
            <div class="thumb">
              <a href="#"><img src="assets/images/course-01.jpg" alt="MCA"/></a>
              <span class="price"><h6>PG</h6></span>
              {/* <!-- <span class="category">Postgraduate</span> --> */}
            </div>
            <div class="down-content">
              <h4>MCA</h4>
              <p>Specialize in software development and computer applications.</p>
              <div class="main-button">
                <a href="/admission">Apply Now</a>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 mb-30 event_outer pg">
          <div class="events_item">
            <div class="thumb">
              <a href="#"><img src="assets/images/course-02.jpg" alt="M.A. English Literature"/></a>
              <span class="price"><h6>PG</h6></span>
             
            </div>
            <div class="down-content">
              <h4>M.A. English Literature</h4>
              <p>Advance your knowledge in English Literature with our postgraduate program.</p>
              <div class="main-button">
                <a href="/admission">Apply Now</a>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 mb-30 event_outer pg">
          <div class="events_item">
            <div class="thumb">
              <a href="#"><img src="assets/images/course-03.jpg" alt="MBA"/></a>
              <span class="price"><h6>PG</h6></span>
             
            </div>
            <div class="down-content">
              <h4>MBA</h4>
              <p>Develop leadership and management skills for a successful career in business.</p>
              <div class="main-button">
                <a href="/admission">Apply Now</a>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 mb-30 event_outer pg">
          <div class="events_item">
            <div class="thumb">
              <a href="#"><img src="assets/images/course-04.jpg" alt="M.Tech"/></a>
              <span class="price"><h6>PG</h6></span>
              
            </div>
            <div class="down-content">
              <h4>M.Tech</h4>
              <p>Master of Technology: Specialized engineering and technology expertise.</p>
              <div class="main-button">
                <a href="/admision">Apply Now</a>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 mb-30 event_outer pg">
          <div class="events_item">
            <div class="thumb">
              <a href="#"><img src="assets/images/course-05.jpg" alt="M.Sc"/></a>
              <span class="price"><h6>PG</h6></span>
             
            </div>
            <div class="down-content">
              <h4>M.Sc</h4>
              <p>Master of Science: Advanced study in scientific and technical fields.</p>
              <div class="main-button">
                <a href="/admission">Apply Now</a>
              </div>
            </div>
          </div>
        </div>
            
                      {/* Add more course items as needed */}
          </div>
        </div>
        <footer>
    <div class="container">
      <div class="col-lg-12">
        <p>Next-Gen:Automated Admission Portal</p>
      </div>
    </div>
  </footer>
      </section>
    </div>
  );
};

