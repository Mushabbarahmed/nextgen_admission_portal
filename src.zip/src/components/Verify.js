
// import React, { useState } from 'react';


// export default function Verify() {
//     const [imageSrc, setImageSrc] = useState('');
//     const fetchImage = async (filename) => {
//         try {
//           console.log("Fetching image:", filename);
//           const response = await fetch(`http://localhost:5000/api/admissions/image/${filename}`);
//           if (response.ok) {
//             console.log("Response OK");
//             const blob = await response.blob();
//             const url = URL.createObjectURL(blob);
//             setImageSrc(url);
//           } else {
//             const errorText = await response.text();
//             console.error('Error fetching the image:', response.status, errorText);
//           }
//         } catch (error) {
//           console.error('Error fetching the image:', error);
//         }
//       };






//   const [selectedFile, setSelectedFile] = useState(null);
//   const [responseText, setResponseText] = useState('');

//   const handleFileChange = (event) => {
//     setSelectedFile(event.target.files[0]);
//   };

//   const sendFileToPython = async () => {
//     const formData = new FormData();
//     formData.append('file', selectedFile);

//     try {
//       const response = await fetch('http://127.0.0.1:5000/upload', {
//         method: 'POST',
//         body: formData,
//       });
//       const result = await response.json();
//       setResponseText(result.text);
//     } catch (error) {
//       console.error('Error:', error);
//     }
//   };

//   return (
    
//     <div className="App">
//      <button onClick={() => fetchImage('Screenshot 2024-06-25 181022.png')}>Fetch Image</button>
//       {imageSrc && <img src={imageSrc} alt="Fetched" style={{ border: "2px solid red", width: "200px", height: "200px" }} />}
  
//      <input type="file" onChange={handleFileChange} />
//      <input type='text' onChange={handleFileChange}/>
//       <button onClick={sendFileToPython}>Send File to Python</button>
//       <p>Response: {responseText}</p>
//     </div>
//   );
// }


import React, { useState } from 'react';

export default function Verify() {
    const [imageSrc, setImageSrc] = useState('');
    const [selectedFile, setSelectedFile] = useState(null);
        const [inputText, setInputText] = useState('');
        const [responseText, setResponseText] = useState('');

    const fetchImage = async (filename) => {
        try {
            console.log("Fetching image:", filename);
            const response = await fetch(`http://localhost:5000/api/admissions/image/${filename}`);
            if (response.ok) {
                console.log("Response OK");
                const blob = await response.blob();
                const url = URL.createObjectURL(blob);
                setImageSrc(url);
            } else {
                const errorText = await response.text();
                console.error('Error fetching the image:', response.status, errorText);
            }
        } catch (error) {
            console.error('Error fetching the image:', error);
        }
    };

    const handleFileChange = (event) => {
        const file = event.target.files[0];
        setSelectedFile(file);
    };

    const handleTextChange = (event) => {
        setInputText(event.target.value);
    };

    const sendFileToPython = async () => {
        const formData = new FormData();
        if (selectedFile) {
            formData.append('file', selectedFile);
        }

        try {
            const response = await fetch('http://127.0.0.1:5000/upload', {
                method: 'POST',
                body: formData,
            });
            const result = await response.json();
            setResponseText(result.text);
        } catch (error) {
            console.error('Error:', error);
        }
    };

    const sendUrlToPython = async () => {
        const formData = new FormData();
        formData.append('url', inputText);

        try {
            const response = await fetch('http://127.0.0.1:5000/upload', {
                method: 'POST',
                body: formData,
            });
            const result = await response.json();
            console.log("work is done ")
            setResponseText(result.text);
        } catch (error) {
            console.error('Error:', error);
        }
    };

    return (
        <div className="App">
            {/* <button onClick={() => fetchImage('Screenshot 2024-06-25 181022.png')}>Fetch Image</button>
            {imageSrc && <img src={imageSrc} alt="Fetched" style={{ border: "2px solid red", width: "200px", height: "200px" }} />}

            <input type="file" onChange={handleFileChange} />
            <button onClick={sendFileToPython}>Send File to Python</button> */}

            <input type="text" onChange={handleTextChange} placeholder="Enter URL" />
            <button onClick={sendUrlToPython}>Send URL to Python</button>
            
            <p>Response: {responseText}</p>
        </div>
    );
}
