import React, { useState } from 'react';
import {
  BsFillArchiveFill, BsFillBellFill, BsFillEnvelopeFill,
  BsFillGrid3X3GapFill, BsGrid1X2Fill, BsJustify,
  BsPeopleFill, BsPersonCircle, BsSearch
} from 'react-icons/bs';
import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import * as XLSX from 'xlsx';
import './Chart.css';

const Header = ({ OpenSidebar }) => {
  return (
    <header className='header'>
      <div className='menu-icon'>
        <BsJustify className='icon' onClick={OpenSidebar} />
      </div>
      <div className='header-left'>
        <BsSearch className='icon' />
      </div>
      <div className='header-right'>
        <BsFillBellFill className='icon' />
        <BsFillEnvelopeFill className='icon' />
        <BsPersonCircle className='icon' />
      </div>
    </header>
  );
};

const Sidebar = ({ openSidebarToggle, OpenSidebar, filterDepartment }) => {
  return (
    <aside className={`sidebar1 ${openSidebarToggle ? "sidebar1-responsive" : ""}`}>
      <div className='sidebar1-title'>
        <div className='sidebar1-brand'>
         
        </div>
        <span className='icon close_icon' onClick={OpenSidebar}>X</span>
      </div>
      <ul className='sidebar1-list'>
        <li className='sidebar1-list-item'>
          <a href="#" onClick={() => filterDepartment(null)}>
            <BsGrid1X2Fill className='icon' /> Dashboard
          </a>
        </li>
        <li className='sidebar1-list-item'>
          <a href="#" onClick={() => filterDepartment('PU')}>
            <BsFillArchiveFill className='icon' /> PU
          </a>
        </li>
        <li className='sidebar1-list-item'>
          <a href="#" onClick={() => filterDepartment('UG')}>
            <BsFillGrid3X3GapFill className='icon' /> UG
          </a>
        </li>
        <li className='sidebar-list-item'>
          <a href="#" onClick={() => filterDepartment('PG')}>
            <BsPeopleFill className='icon' /> PG
          </a>
        </li>
       
      </ul>
    </aside>
  );
};

const Chart = () => {
  const [data, setData] = useState([]);
  const [openSidebarToggle, setOpenSidebarToggle] = useState(false);
  const [filteredData, setFilteredData] = useState([]);

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = (e) => {
      const binaryStr = e.target.result;
      const workbook = XLSX.read(binaryStr, { type: 'binary' });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const parsedData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

      const formattedData = parsedData.slice(1).map((row) => ({
        Gender: row[0],
        Age: row[1],
        Nationality: row[2],
        State: row[3],
        PhysicallyChallenged: row[4],
        Verified: row[5],
        Department: row[6],
        Timestamp: row[7],
      }));

      setData(formattedData);
      setFilteredData(formattedData);
    };

    reader.readAsBinaryString(file);
  };

  const handleSidebarToggle = () => {
    setOpenSidebarToggle(!openSidebarToggle);
  };

  const filterDepartment = (department) => {
    if (department) {
      setFilteredData(data.filter(item => item.Department === department));
    } else {
      setFilteredData(data);
    }
  };

  const totalApplications = filteredData.length;
  const puApplications = filteredData.filter(item => item.Department === 'PU').length;
  const ugApplications = filteredData.filter(item => item.Department === 'UG').length;
  const pgApplications = filteredData.filter(item => item.Department === 'PG').length;

  const verifiedCount = filteredData.filter(item => item.Verified === 'Yes').length;
  const notVerifiedCount = filteredData.filter(item => item.Verified === 'No').length;

  const pieData = [
    { name: 'Verified', value: verifiedCount },
    { name: 'Not Verified', value: notVerifiedCount },
  ];

  const nationalityData = filteredData.reduce((acc, item) => {
    if (!acc[item.Nationality]) {
      acc[item.Nationality] = 0;
    }
    acc[item.Nationality]++;
    return acc;
  }, {});

  const nationalityPieData = Object.keys(nationalityData).map(nationality => ({
    name: nationality,
    value: nationalityData[nationality],
  }));

  const stateData = filteredData.reduce((acc, item) => {
    if (!acc[item.State]) {
      acc[item.State] = 0;
    }
    acc[item.State]++;
    return acc;
  }, {});

  const statePieData = Object.keys(stateData).map(state => ({
    name: state,
    value: stateData[state],
  }));

  const departmentData = filteredData.reduce((acc, item) => {
    if (!acc[item.Department]) {
      acc[item.Department] = 0;
    }
    acc[item.Department]++;
    return acc;
  }, {});

  const departmentBarData = Object.keys(departmentData).map(department => ({
    Department: department,
    Count: departmentData[department],
  }));

  const ageRanges = {
    '18-20': 0,
    '21-23': 0,
    '24-26': 0,
    '27+': 0,
  };

  filteredData.forEach(item => {
    const age = parseInt(item.Age, 10);
    if (age >= 18 && age <= 20) ageRanges['18-20']++;
    else if (age >= 21 && age <= 23) ageRanges['21-23']++;
    else if (age >= 24 && age <= 26) ageRanges['24-26']++;
    else if (age >= 27) ageRanges['27+']++;
  });

  const ageBarData = Object.keys(ageRanges).map(range => ({
    range,
    count: ageRanges[range],
  }));

  const genderDepartmentData = filteredData.reduce((acc, item) => {
    if (!acc[item.Department]) {
      acc[item.Department] = { Male: 0, Female: 0 };
    }
    if (item.Gender === 'Male') acc[item.Department].Male++;
    else if (item.Gender === 'Female') acc[item.Department].Female++;
    return acc;
  }, {});

  const stackedBarData = Object.keys(genderDepartmentData).map(department => ({
    Department: department,
    Male: genderDepartmentData[department].Male,
    Female: genderDepartmentData[department].Female,
  }));

  const ageVerificationData = filteredData.reduce((acc, item) => {
    const ageGroup = item.Age < 25 ? 'Under 25' : '25 and above';
    if (!acc[ageGroup]) {
      acc[ageGroup] = { Verified: 0, NotVerified: 0 };
    }
    if (item.Verified === 'Yes') acc[ageGroup].Verified++;
    else acc[ageGroup].NotVerified++;
    return acc;
  }, {});

  const ageVerificationBarData = Object.keys(ageVerificationData).map(group => ({
    ageGroup: group,
    Verified: ageVerificationData[group].Verified,
    NotVerified: ageVerificationData[group].NotVerified,
  }));

  const physicalChallengeData = filteredData.reduce((acc, item) => {
    if (!acc[item.PhysicallyChallenged]) {
      acc[item.PhysicallyChallenged] = 0;
    }
    acc[item.PhysicallyChallenged]++;
    return acc;
  }, {});

  const physicalDonutData = Object.keys(physicalChallengeData).map(challenge => ({
    name: challenge,
    value: physicalChallengeData[challenge],
  }));

  // Define state colors
  const stateColors = {
    'California': '#ff9999',
    'New York': '#66b3ff',
    'Texas': '#99ff99',
    'Florida': '#ffcc99',
    'Other': '#c2c2f0'
  };

  // Assign colors to states
  const coloredStatePieData = statePieData.map((entry) => ({
    ...entry,
    fill: stateColors[entry.name] || '#2980b9' // Use a default color if not in stateColors
  }));

  

  return (
    <div className="container1">
      <Header OpenSidebar={handleSidebarToggle} />
      <Sidebar openSidebarToggle={openSidebarToggle} OpenSidebar={handleSidebarToggle} filterDepartment={filterDepartment} />
      <main className="main">
        <div className="main-header">
          <h1>Dashboard</h1>
          <input type="file" onChange={handleFileUpload} />
        </div>
        <div className="main-overview">
       
          <div className="overview-card">
            <h2>Total Applications</h2>
            <p>{totalApplications}</p>
          </div>
          <div className="overview-card">
            <h2>PU Applications</h2>
            <p>{puApplications}</p>
          </div>
          <div className="overview-card">
            <h2>UG Applications</h2>
            <p>{ugApplications}</p>
          </div>
          <div className="overview-card">
            <h2>PG Applications</h2>
            <p>{pgApplications}</p>
          </div>
        
        </div>
        <div className="main-charts">
        <div className="chart-container">
            <h2>Age Distribution</h2>
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={ageBarData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="range" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="chart-container">
            <h2>Application Status</h2>
            <ResponsiveContainer width="100%" height={400}>
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={60} fill="#8884d8" label>
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index === 0 ? "#ff7f0e" : "#1f77b4"} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>



          <div className="chart">
  <h2>Nationality Distribution</h2>
  <ResponsiveContainer width="100%" height={300}>
    <PieChart>
      <Tooltip />
      <Pie 
        data={nationalityPieData} 
        dataKey="value" 
        nameKey="name" 
        cx="50%" 
        cy="50%" 
        outerRadius={80} 
        innerRadius={50} // Set innerRadius to create a donut chart
        fill="#8884d8"
      >
        {nationalityPieData.map((entry, index) => (
          <Cell 
            key={`cell-${index}`} 
            fill={entry.name === 'Indian' ? "#2980b9" : "#82ca9d"} 
          />
        ))}
      </Pie>
    </PieChart>
  </ResponsiveContainer>
</div>



          <div className="chart-container">
            <h2>State Distribution</h2>
            <ResponsiveContainer width="100%" height={400}>
              <PieChart>
                <Pie data={coloredStatePieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={60} fill="#d35400" label>
                  {coloredStatePieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>

          

          <div className="chart-container">
  <h2>Gender Distribution by Department</h2>
  <ResponsiveContainer width="100%" height={400}>
    <BarChart data={stackedBarData}>
      <CartesianGrid strokeDasharray="3 3" />
      <XAxis dataKey="Department" />
      <YAxis />
      <Tooltip />
      <Bar dataKey="Male" stackId="a" fill="#b7950b" />
      <Bar dataKey="Female" stackId="a" fill="#34495e" />
    </BarChart>
  </ResponsiveContainer>
</div>


         
          
          
         



          <div className="chart-container">
            <h2>Age vs Verification Status</h2>
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={ageVerificationBarData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="ageGroup" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="Verified" stackId="a" fill="#f1948a" />
                <Bar dataKey="NotVerified" stackId="a" fill="#76d7c4" />
              </BarChart>
            </ResponsiveContainer>
          </div>


          <div className="chart-container">
            <h2>Physical Challenge Distribution</h2>
            <ResponsiveContainer width="100%" height={400}>
              <PieChart>
                <Pie data={physicalDonutData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={40} outerRadius={60} fill="#8884d8" label>
                  {physicalDonutData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.name === 'Yes' ? "#8884d8" : "#82ca9d"} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="chart-container">
            <h2>Department Distribution</h2>
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={departmentBarData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="Department" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="Count" fill="#d2b4de" />
              </BarChart>
            </ResponsiveContainer>
          </div>

        </div>
      </main>
    </div>
  );
};

export default Chart;
