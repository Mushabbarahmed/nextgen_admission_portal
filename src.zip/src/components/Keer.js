import React, { useState } from 'react';

function Keer() {
  const [image, setImage] = useState(null);
  const [imageUrl, setImageUrl] = useState(null); // State to store fetched image URL
  const [cloudinaryPublicId, setCloudinaryPublicId] = useState(null); // State to store cloudinary public id

  const uploadPreset = 'keerthana'; // Replace with your actual upload preset name
  const cloudName = 'dpmjqrygj'; // Replace with your Cloudinary cloud name

  const submitImage = () => {
    if (!image) {
      console.log("No image selected");
      return;
    }

    const formData = new FormData();
    formData.append("file", image);
    formData.append("upload_preset", uploadPreset);
    formData.append("cloud_name", cloudName);

    fetch(`https://api.cloudinary.com/v1_1/${cloudName}/image/upload`, {
      method: "POST",
      body: formData
    })
    .then(res => {
      if (!res.ok) {
        throw new Error('Network response was not ok');
      }
      return res.json();
    })
    .then(data => {
      console.log("Upload successful:", data);
      // Extract and store the public_id from the response
      const publicId = data.public_id;
      setCloudinaryPublicId(publicId); // Store the public_id in state
      fetchImageUrl(publicId); // Fetch and display the image URL
    })
    .catch(error => {
      console.error("Error uploading image:", error);
      // Handle errors here, e.g., show error message to the user
    });
  }

  const fetchImageUrl = (publicId) => {
    // Construct the URL to fetch the image from Cloudinary using the public ID
    const imageUrl = `https://res.cloudinary.com/${cloudName}/image/upload/${publicId}`;

    // Perform a GET request to fetch the image
    fetch(imageUrl)
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.url;
      })
      .then(data => {
        console.log("Fetch successful:", data);
        setImageUrl(data); // Set the image URL in state to display it
      })
      .catch(error => {
        console.error("Error fetching image:", error);
        // Handle errors here, e.g., show error message to the user
      });
  }

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    setImage(file);
  }

  return (
    <div>
      <h1>Upload and Fetch Your Image</h1>
      <input type="file" onChange={handleImageChange} />
      <button onClick={submitImage}>Upload</button>

      {imageUrl && (
        <div>
          <h2>Fetched Image URL:</h2>
          <p>{imageUrl}</p>
        </div>
      )}
    </div>
  );
}

export default Keer;

